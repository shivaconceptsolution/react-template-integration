import { Link } from "react-router-dom";

function About()
{
    return(<div>
 <div className="hero_area">
  
    <header className="header_section">
      <div className="container">
        <div className="header_nav">
          <a className="navbar-brand brand_desktop" href="index.html">
            <img src="images/logo.png" alt="" />
          </a>
          <div className="main_nav">
            <div className="top_nav">
              <ul className=" ">
                <li className="">
                  <a className="" href="">
                    <img src="images/telephone.png" alt="" />
                    <span> +01 1234567890</span>
                  </a>
                </li>
                <li className="">
                  <a className="" href="">
                    <img src="images/mail.png" alt="" />
                    <span>demo@gmail.com</span>
                  </a>
                </li>
                <li className="">
                  <a className="" href="">
                    <img src="images/location.png" alt="" />
                    <span>Den mark Loram ipusum</span>
                  </a>
                </li>
              </ul>
            </div>
            <div className="bottom_nav">
              <nav className="navbar navbar-expand-lg custom_nav-container">
                <a className="navbar-brand brand_mobile" href="index.html">
                  <img src="images/logo.png" alt="" />
                </a>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                  <div className="d-flex ml-auto flex-column flex-lg-row align-items-center">
                  <ul className="navbar-nav  ">
                      <li className="nav-item active">
                        <Link className="nav-link" to="/home">Home <span className="sr-only">(current)</span></Link>
                      </li>
                      <li className="nav-item">
                        <Link className="nav-link" to="/about"> About </Link>
                      </li>
                     
                    </ul>
                    <form className="form-inline">
                      <button className="btn ml-3 ml-lg-5 nav_search-btn" type="submit"></button>
                    </form>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </header>
   
  </div>

  

  <section className="about_section layout_padding">
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-10 ml-auto pr-0">
          <div className="about_container">
            <div className="row">
              <div className="col-lg-3 col-md-5">
                <div className="detail-box">
                  <div className="heading_container">
                    <h2>
                      About Class
                    </h2>
                  </div>
                  <p>
                    iusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris iusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquipnisi ut aliquipiusmod tempor incididunt ut labore et
                  </p>
                  <hr />
                  <a href="">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 
 
  <div className="info_section">
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-10 ml-auto">
          <div className="row info_main-row">
            <div className="col-md-6 pr-0">

            

              <section className="contact_section">
                <h2>
                  Request A Call Back
                </h2>
                <form action="">
                  <div>
                    <input type="text" placeholder="Name" />
                  </div>
                  <div>
                    <input type="text" placeholder="Phone Number" />
                  </div>
                  <div>
                    <input type="email" placeholder="Email" />
                  </div>
                  <div>
                    <input type="text" className="message-box" placeholder="Message" />
                  </div>
                  <div className="d-flex ">
                    <button>
                      SEND
                    </button>
                  </div>
                </form>
                <div className="map_container">
                  <div className="map">
                    <div id="googleMap" style={{width:'100%',height:'300px'}}></div>
                  </div>
                </div>
              </section>

           

         
              <section className=" footer_section ">
                <div className="social_box">
                  <a href="#">
                    <img src="images/facebook.png" alt="" />
                  </a>
                  <a href="#">
                    <img src="images/twitter.png" alt="" />
                  </a>
                  <a href="#">
                    <img src="images/linkedin.png" alt="" />
                  </a>
                  <a href="#">
                    <img src="images/instagram.png" alt="" />
                  </a>
                  <a href="#">
                    <img src="images/youtube.png" alt="" />
                  </a>
                </div>
                <p>
                  &copy; 2020 All Rights Reserved. Design by
                  <a href="https://html.design/">Free Html Templates</a>
                </p>
              </section>
             

            </div>
            <div className="col-md-6  px-0">
              <div className="img-box">
                <img src="images/footer-img.jpg" alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    </div>)
}
export default About;