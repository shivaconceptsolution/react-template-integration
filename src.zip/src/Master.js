import { Outlet } from "react-router-dom";

function Master()
{
    return(<>
       <Outlet />
    </>)
}
export default Master;